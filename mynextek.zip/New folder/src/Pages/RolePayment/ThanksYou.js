import React from "react";

function ThanksYou() {
  return <div>Thanks For The Payment</div>;
}

export default ThanksYou;
